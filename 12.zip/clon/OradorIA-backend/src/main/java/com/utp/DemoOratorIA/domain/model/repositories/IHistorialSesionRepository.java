package com.utp.DemoOratorIA.domain.model.repositories;

import java.util.List;

import com.utp.DemoOratorIA.domain.model.aggregate.HistorialSesion;

public interface IHistorialSesionRepository extends ICRUD<HistorialSesion> {
List<HistorialSesion> listarPorUsuario(Integer idUsuario);
}