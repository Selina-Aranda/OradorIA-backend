package com.utp.DemoOratorIA.infraestructure.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

import com.utp.DemoOratorIA.infraestructure.entities.HistorialSesionEntity;

public interface JPAHistorialSesionRepository extends JpaRepository<HistorialSesionEntity, Integer> {

List<HistorialSesionEntity> findByIdUsuario(Integer idUsuario);
}